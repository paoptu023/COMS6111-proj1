import urllib2
import base64
import sys
import query_processor
import json
import parameters
import re
import operator
from urlparse import urlparse


# parse the initial input query
def process_raw_query(raw):
    print 'Parsing the input query ... '
    temp = raw.lower().split()
    rst = {}
    for term in temp:
        rst[term] = 1
    return rst


# compose the query url
def compose_url(query_dic, n):
    bing_url = 'https://api.datamarket.azure.com/Bing/Search/Web?Query=%27'
    cnt = 0;
    q = []
    reorder_q = sorted(query_dic.items(), key=operator.itemgetter(1), reverse=True)
    while cnt<len(reorder_q):
        bing_url += '+'+reorder_q[cnt][0]
        q.append(reorder_q[cnt][0])
        cnt += 1
    bing_url += '%27&$top=' + str(n) + '&$format=json'
    return (q, bing_url)


# parse url, get the last two components, remove digits and special characters
def parse_url(url):
    path = urlparse(url).path.replace('.html', '')
    path = ''.join(i for i in path if not i.isdigit())
    result = path.split('/')[-1] + ' ' + path.split('/')[-2]
    result = re.sub('[^a-zA-Z\n\.]', ' ', result)
    return result


def parse_title(title):
    pos = 0
    while pos<len(title) and (title[pos].isalpha() or title[pos] == ' '):
        pos += 1
    return title[:pos]


# parse the query response to get formatted results
def get_result(response, transcript):
    json_result = json.loads(response)
    result_list = json_result['d']['results']
    result = []
    count = 0
    for data in result_list:
        temp = {}
        count += 1
        temp['Url'] = data['Url']
        temp['Title'] = data['Title']
        temp['Description'] = data['Description']
        print '======================================'
        transcript.write('======================================\n')
        print 'Result ', count
        transcript.write('Result %d\n' % count)
        print 'Url            : ', temp['Url']
        transcript.write('Url            : %s\n' % temp['Url'].encode('utf8'))
        print 'Title          : ', temp['Title']
        transcript.write('Title          : %s\n' % temp['Title'].encode('utf8'))
        print 'Description    : ', temp['Description']
        transcript.write('Description    : %s\n' % temp['Description'].encode('utf8'))
        print '======================================'
        transcript.write('======================================\n')
        while 1:
            fb = raw_input('Relevant (Y/N)?').lower()
            if fb == 'y' or fb == 'n':
                temp['Feedback'] = fb
                transcript.write('Feedback: %s\n' % fb)
                break
            else:
                print 'Please input Y/N to indicate the relevance'
        result.append(temp)
    return result


def main():
    transcript = open("cur_transcript.txt", "a")
    # parse accountKey
    account_key = sys.argv[1]
    account_key_encry = base64.b64encode(account_key + ':' + account_key)
    headers = {'Authorization': 'Basic ' + account_key_encry}

    # get input precision
    exp_precision = float(sys.argv[2])
    # parse raw query
    query = process_raw_query(sys.argv[3])

    cur_precision = 0.01
    parameters.param.read_stop_words()

    rnd = 0

    while exp_precision > cur_precision:
        rnd += 1
        print 'ROUND ', rnd
        transcript.write('ROUND ' + str(rnd) + '\n')
        print 'Parameters:'
        transcript.write('Parameters:\n')
        print 'Client key = ', account_key
        transcript.write('Client key = ' + account_key + '\n')
        
        
        # query bing to get results
        q, cur_url = compose_url(query, parameters.param.num)
        transcript.write('Query : ' + ' '.join(q) + '\n')

        print 'Query = ', ' '.join(q)
        print 'URL : ',cur_url
        req = urllib2.Request(cur_url, headers=headers)
        resp = urllib2.urlopen(req).read()

        # form new query process object and initialize the relative parameters
        helper = query_processor.processor(query)
        cur_precision = 0

        # classify the result docs
        for row in get_result(resp, transcript):
            if row['Feedback'] == 'y':
                helper.add_relevant_doc(row['Description'] + ' ' + parse_title(row['Title']) + ' ' + parse_url(row['Url']))
                cur_precision += 1
            else:
                helper.add_non_relevant_doc(row['Description'] + ' ' + parse_title(row['Title']) + ' ' + parse_url(row['Url']))

        # calculate the new precision
        cur_precision = float(cur_precision)/parameters.param.num
        transcript.write('Current precision of relevance is : %f\n' % cur_precision)

        # the program terminates when no relevant doc found or achieve the expected precision
        if cur_precision == 0:
            transcript.write('Opps, none relevant docs found, consider another query\n')
            sys.exit('Opps, none relevant docs found, consider another query')
        elif exp_precision <= cur_precision:
            print 'Achieved the required precision'
            break
        else:
            print '======================================'
            transcript.write('======================================\n')
            print 'FEEDBACK SUMMARY'
            transcript.write('FEEDBACK SUMMARY\n')
            print 'Query : ', ' '.join(q)
            transcript.write('Query : ' + ' '.join(q) + '\n')
            print 'Precision :', cur_precision
            transcript.write('Precision :' + str(cur_precision) + '\n')
            print 'Still below the desired precision of ', exp_precision
            transcript.write('Still below the desired precision of ' + str(exp_precision) + '\n')
            print 'Indexing result ...'
            transcript.write('Indexing result ...\n')
            augment, query = helper.form_query()
            print 'Augmenting by', ' '.join(augment)
            transcript.write('Augmenting by' + ' '.join(augment) + '\n')
            print '======================================\n'
            transcript.write('======================================\n')
    
    transcript.write('Achieved the required precision\n\n')
    transcript.close()
    exit()

# entrance of the program
if __name__ == "__main__":
    main()
